# logo > 2022-11-21 5:50pm
https://universe.roboflow.com/ga-nc1se/logo-dgnho

Provided by a Roboflow user
License: CC BY 4.0

